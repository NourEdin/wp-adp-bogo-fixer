<?php

if (!defined('ABSPATH'))
    die('Silence is golden');